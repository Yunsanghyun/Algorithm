#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

std::vector<int> team_list;
std::vector<int> team1_list;
std::vector<int> team2_list;
std::vector<int> team_visit;
std::vector<int> total_visit;

int total_num = 0;
int team_num = 0;
int team_cnt = 0; // ��ü���� �� ������
int two_cnt = 0; // ������ 2�� ������

int team1_score = 0;
int team2_score = 0;
int temp_score = 0;
int score_gap = 0;
int min_gap = 4500;

int talent_table[20][20];

void team1_select(int num, int start);
void team2_select();
void team_score(std::vector<int>& target_team);
void print_v(std::vector<int>& v);

int main() {
	int temp = 0;

	scanf("%d", &total_num);
	team_num = total_num / 2;

	for (int i = 0; i < total_num; i++) {
		for (int j = 0; j < total_num; j++) {
			scanf("%d", &talent_table[i][j]);
		}
	}

	// �湮���� �ʱ�ȭ
	for (int a = 0; a < total_num; a++) {
		total_visit.push_back(0);
	}
	for (int b = 0; b < team_num; b++) {
		team_visit.push_back(0);
	}

	team1_select(team_num, 0);

	printf("%d", min_gap);

	return 0;
}

// 1,2�� ������ �����Ѵ�.
void team1_select(int num, int start) {
	if (team_cnt == num) {
		// 1�� ������ �������� 2�� ������ ����
		team2_select();

		/*
		printf("��1 ���� = ");
		print_v(team1_list);
		printf("��2 ���� = ");
		print_v(team2_list);
		*/

		// �� ���� ������ ����
		team_score(team1_list);
		team1_score = temp_score;
		temp_score = 0;
		team_list.clear();
		two_cnt = 0;

		team_score(team2_list);
		team2_score = temp_score;
		temp_score = 0;
		team_list.clear();
		two_cnt = 0;

		// ���� ��������
		score_gap = team1_score - team2_score;
		if (score_gap < 0)
			score_gap *= -1;

		//printf("1�� %d 2�� %d ���� %d\n", team1_score, team2_score, score_gap);

		// �� ������ �ּҰ�
		if (min_gap > score_gap)
			min_gap = score_gap;
		
		return;
	}
	for (int i = start; i < total_num; i++) {
		if (total_visit[i] == 0) {
			total_visit[i] = 1;
			team1_list.push_back(i);
			team_cnt++;

			team1_select(num, start + 1);

			total_visit[i] = 0;
			team1_list.pop_back();
			start++;
			team_cnt--;
		}
	}
}

void team2_select() {
	int flag = 0;
	// �ʱ�ȭ
	team2_list.clear();
	for (int i = 0; i < total_num; i++) {
		flag = 0;
		for (int j = 0; j < team_num; j++) {
			if (i == team1_list[j]) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			team2_list.push_back(i);
		}
	}
}

// ���� ������ ����
void team_score(std::vector<int>& target_team) {
	if (two_cnt == 2) {
		temp_score += talent_table[team_list[0]][team_list[1]];
		return;
	}
	for (int i = 0; i < team_num; i++) {
		if (team_visit[i] == 0) {
			team_visit[i] = 1;
			team_list.push_back(target_team[i]);
			two_cnt++;

			team_score(target_team);

			team_visit[i] = 0;
			team_list.pop_back();
			two_cnt--;
		}
	}

	return;
}

void print_v(std::vector<int>& v) {
	std::vector<int>::iterator itr;
	for (itr = v.begin(); itr!= v.end(); itr++) {
		printf("%d ", *itr + 1);
	}
	printf("\n");
}