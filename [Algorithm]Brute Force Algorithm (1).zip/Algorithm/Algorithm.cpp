#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>

int cnt_colunm = 0;
int safe_space_cnt = 0;
int max_cnt = 0;
int N, M;
int	matrix[8][8];
int temp_matrix[8][8];

void cal();
void print_f();
int find();
void virus();

int main() {
	// N�� ����, M�� ����
	int cnt = 0;

	scanf("%d %d", &N, &M);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			scanf("%d", &matrix[i][j]);
		}
	}

	cal();
	printf("%d", max_cnt);

	return 0;
}

void cal() {
	safe_space_cnt = 0;

	// ��� 3�� ����
	if (cnt_colunm == 3) {
		safe_space_cnt = find();
		if (max_cnt < safe_space_cnt) {
			max_cnt = safe_space_cnt;
		//	print_f();
		}
		return;
	}

	// N ��, M ��
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if (matrix[i][j] == 0) {
				matrix[i][j] = 1;
				cnt_colunm++;
				cal();
				matrix[i][j] = 0;
				cnt_colunm--;
			}
		}
	}
}

int find() {
	int cnt = 0;
	
	// ����
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			temp_matrix[i][j] = matrix[i][j];
		}
	}

	virus();

	// N ��, M ��
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if (temp_matrix[i][j] == 0)
				cnt++;
		}
	}

	return cnt;
}

void print_f() {
	printf("\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			printf("%d ", temp_matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void virus() {
	int spread_cnt;

	while (1) {
		spread_cnt = 0;
		// ���̷��� ����
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				// ���̷��� �������� ����
				if (temp_matrix[i][j] == 2) {
					if (j - 1 >= 0 && temp_matrix[i][j - 1] == 0) {
						temp_matrix[i][j - 1] = 2;
						spread_cnt++;
					}

					if (j + 1 < M && temp_matrix[i][j + 1] == 0) {
						temp_matrix[i][j + 1] = 2;
						spread_cnt++;
					}
					if (i - 1 >= 0 && temp_matrix[i - 1][j] == 0) {
						temp_matrix[i - 1][j] = 2;
						spread_cnt++;
					}
					if (i + 1 < N && temp_matrix[i + 1][j] == 0) {
						temp_matrix[i + 1][j] = 2;
						spread_cnt++;
					}
				}
			}
		}
		if (spread_cnt == 0)
			break;
	}
	return;
}