#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>

int num = 0;
int cnt = 0;
std::vector<int> temp;

void cal(std::vector<int>& vec, int start);

int main() {
	int a;
	std::vector<int> v;

	while (1){ 
		scanf("%d", &num);
		if (num == 0)
			break;

		for (int i = 0; i < num; i++) {
			scanf("%d",&a);
			v.push_back(a);
		}

		cal(v,0);
		printf("\n");
		v.clear();
	}
	return 0;
}

// 6�� ���ڸ� �̾ƾ���
// 6�� �� ������ ��
void cal(std::vector<int>& vec,int start) {
	if (cnt == 6) {
		for (int j = 0; j < 6; j++) {
			printf("%d ", temp[j]);
		}
		printf("\n");
		return;
	}

	for (int i = start; i < num; i++) {
		temp.push_back(vec[i]);
		cnt++;

		cal(vec, start + 1);
		
		temp.pop_back();
		start++;
		cnt--;
	}
	return;
}