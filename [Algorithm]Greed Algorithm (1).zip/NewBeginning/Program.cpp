#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <algorithm>

int num = 0;
int cnt = 0;
int min = 0;

int main() {
	int a = 0;
	std::vector<int> time;

	scanf("%d", &num);

	for (int i = 0; i < num; i++) {
		std::cin >> a;
		time.push_back(a);
	}

	std::sort(time.begin(), time.end());

	for (std::vector<int>::iterator itr1 = time.begin(); itr1 != time.end(); itr1++) {
		for (std::vector<int>::iterator itr2 = time.begin(); itr2 != itr1 + 1; itr2++) {
			min += *itr2;
		}
	}

	printf("%d", min);
	
	return 0;
}