#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

int arr[3][3];
int num = 0;
int DP(std::vector<std::pair<int, int>>& v);

bool com(const std::pair<int, int>& a, const std::pair<int, int>& b) {
	return a.second < b.second;
}

int main() {
	std::vector<std::pair<int, int>> v;
	std::pair<int, int> p;

	int temp_x = 0;
	int temp_y = 0;
	int cnt = 0;

	scanf("%d", &num);
	for (int i = 0; i < num; i++) {
		scanf("%d %d", &temp_x, &temp_y);
		p.first = temp_x;
		p.second = temp_y;
		v.push_back(p);
	}

	std::sort(v.begin(), v.end());
	std::sort(v.begin(), v.end(), com);

	cnt = DP(v);

	printf("%d", cnt);

	return 0;
}

int DP(std::vector<std::pair<int, int>>& v) {
	int cnt = 1;
	int max = v[0].second;

	for (int i = 1; i < num; i++) {
		if (v[i].first >= max) {
			cnt++;
			max = v[i].second;
		}
	}
	return cnt;
}
